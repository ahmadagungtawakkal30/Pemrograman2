# -*- coding: utf-8 -*-
"""
Created on Thu Oct 31 00:17:55 2019

@author: Ahmad Agung Tawakkal
"""

def NPM4(npm):
    NPM = input ("Masukan NPM : ")
    print ("Halo, ",NPM[4]," apa kabar ?")
NPM4(npm)