# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 14:16:19 2019

@author: ahmad agung tawakkal
"""

import kelas3lib

npm = input ("Masukan NPM : ")
kelas = kelas3lib.NPM(npm)
fungsi = kelas.NPM1() #NPM1 adalah fungsi jadi dapat memanggil fungsi NPM yang lain

print("")

