# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 14:16:19 2019

@author: ahmad agung tawakkal
"""

import lib3

class NPM:
    def __init__(self,npm):
        delf.npm = npm
    def NPM1(self):
        return lib3.NPM1(self.npm)
    def NPM2(self):
        return lib3.NPM2(self.npm)
    def NPM3(self):
        return lib3.NPM3(self.npm)
    def NPM4(self):
        return lib3.NPM4(self.npm)
    def NPM5(self):
        return lib3.NPM5(self.npm)
    def NPM6(self):
        return lib3.NPM6(self.npm)
    def NPM7(self):
        return lib3.NPM7(self.npm)
    def NPM8(self):
        return lib3.NPM8(self.npm)
    def NPM9(self):
        return lib3.NPM9(self.npm)
    def NPM10(self):
        return lib3.NPM10(self.npm)