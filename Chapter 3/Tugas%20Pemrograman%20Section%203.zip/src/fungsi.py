# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 19:38:13 2019

@author: Ahmad Agung Tawakkal
"""


def salam():
    nama = input()
    print ("Hello, Selamat Pagi "+nama)
    
salam()


#Output 
#Agung                          -inputan
#Hello, Selamat Pagi Agung      -hasil