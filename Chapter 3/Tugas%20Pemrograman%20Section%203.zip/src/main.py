# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 23:03:32 2019

@author: Ahmad Agung Tawakkal
"""

from kalkulator import Penambahan #memanggil file kalkulator dari library kemudian memanggil fungsi penambahan

c=Penambahan(3,2)
print (c)