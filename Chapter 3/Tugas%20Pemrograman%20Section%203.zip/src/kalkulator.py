# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 22:16:58 2019

@author: Ahmad Agung Tawakkal
"""

def Penambahan(a,b):
    r = a + b
    return r
def Pengurangan(a,b):
    r = a - b
    return r
def Perkalian(a,b):
    r = a * b
    return r
def Pembagian(a,b):
    r = a / b
    return r

