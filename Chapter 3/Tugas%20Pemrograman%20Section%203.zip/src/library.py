# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 20:16:55 2019

@author: Ahmad Agung Tawakkal
"""

#contoh menggunakan import

import fungsi

c=fungsi.salam()
print (c)