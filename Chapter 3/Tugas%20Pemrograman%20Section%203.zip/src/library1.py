# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 20:16:55 2019

@author: Ahmad Agung Tawakkal
"""

#Contoh menggunakan from

from fungsi import salam

c=salam()
print (c)