# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 20:20:51 2019

@author: Ahmad Agung Tawakkal
"""

def salam():
    nama = input()
    print ("Hello, Selamat Pagi "+nama)
    
salam()

def nama_lenkap():
    depan=input()
    belakang=input()
    print ("Hay "+depan+belakang)

nama_lenkap()